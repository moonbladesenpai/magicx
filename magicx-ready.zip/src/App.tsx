import { useEffect, useMemo, useState, type FormEvent } from 'react';

const PHONE = 'tel:01336580900';
const WHATSAPP = 'https://wa.me/message/RN4HQHNW4GLSG1';
const FACEBOOK = 'https://www.facebook.com/share/1CRYF44Qed/';
const WEB3FORMS_ACCESS_KEY = 'b2e60f56-33ef-4c24-a53a-6a154727fc36';

const PACKAGES = {
  starter: { label: 'Starter Pack — ১০ পিস', short: 'Starter Pack', qty: '১০ পিস', price: 490, note: 'প্রতি পিস মাত্র ৳৪৯' },
  premier: { label: 'Premier Pack — ২০ পিস', short: 'Premier Pack', qty: '২০ পিস', price: 900, note: 'ডাবল কোয়ান্টিটি, ডাবল ভ্যালু' },
} as const;

const DELIVERY_OPTIONS = {
  inside: { label: 'ঢাকার ভিতরে', price: 60, time: '২৪-৭২ ঘণ্টা' },
  outside: { label: 'ঢাকার বাইরে', price: 120, time: '২-৪ কার্যদিবস' },
} as const;

const PRODUCT_IMAGES = ['/assets/product-1.jpg', '/assets/product-2.jpg', '/assets/product-3.jpg', '/assets/product-4.jpg'];

const BENEFITS = [
  'সহবাসে ৩০–৪০ মিনিট দীর্ঘস্থায়িত্বের গ্যারান্টি',
  'ভিটামিন E সমৃদ্ধ — কোনো ক্ষতি ছাড়াই কাজ করে',
  'জার্মান ল্যাব টেস্টেড — পার্শ্বপ্রতিক্রিয়ামুক্ত',
  'ডায়াবেটিস ও হার্টের রোগীরাও ব্যবহার করতে পারবেন',
  'মাত্র ২ মিনিটে কাজ শুরু করে',
  'পকেট সাইজ — সহজে বহনযোগ্য',
];

const TRUST_ITEMS = [
  { icon: '🔬', label: 'জার্মান ল্যাব টেস্টেড' },
  { icon: '🛡️', label: 'সাইড ইফেক্ট মুক্ত' },
  { icon: '📦', label: 'গোপন প্যাকেজিং' },
  { icon: '💵', label: 'ক্যাশ অন ডেলিভারি' },
];

const SERVICES = [
  { icon: '🚚', title: 'দ্রুত ডেলিভারি', sub: '২৪-৭২ ঘণ্টা' },
  { icon: '🔒', title: 'গোপন প্যাকেজ', sub: '১০০% প্রাইভেট' },
  { icon: '💵', title: 'ক্যাশ অন ডেলিভারি', sub: 'পেয়ে পেমেন্ট' },
];

const STEPS = [
  { icon: '🧼', label: 'ধাপ ১', title: 'পরিষ্কার করুন', body: 'সহবাসের ২-৩ মিনিট আগে ভালো করে ধুয়ে শুকনো করুন।' },
  {
    icon: '✋',
    label: 'ধাপ ২',
    title: 'টিস্যু লাগান',
    body: 'লিঙ্গের আগা থেকে মাঝ পর্যন্ত ২-৩ বার মুছুন এবং চারপাশে মালিশ করুন। ৩০ সেকেন্ডে শুকিয়ে যাবে।',
  },
  {
    icon: '⏰',
    label: 'ধাপ ৩',
    title: '২ মিনিট অপেক্ষা করুন',
    body: '২ মিনিট অপেক্ষার পর সহবাসে যান এবং ৩০-৪০ মিনিটের সুখময় অভিজ্ঞতা উপভোগ করুন।',
  },
];

const WHY_ITEMS = [
  { icon: '🏆', title: 'জার্মান মানের নিশ্চয়তা', body: 'আন্তর্জাতিক মানের পরীক্ষায় উত্তীর্ণ, প্রামাণিত ফলাফল' },
  { icon: '🛡️', title: '১০০% নিরাপদ', body: 'কোনো রাসায়নিক পার্শ্বপ্রতিক্রিয়া নেই, ডাক্তারদের পরীক্ষিত' },
  { icon: '⚡', title: 'দ্রুত ফলাফল', body: 'মাত্র ২ মিনিটে কার্যকর, দীর্ঘস্থায়ী প্রভাব ৩০-৪০ মিনিট' },
  { icon: '🔐', title: 'গোপনীয়তা নিশ্চিত', body: 'সম্পূর্ণ গোপন প্যাকেজিং, কেউ বুঝতে পারবে না' },
];

const REVIEWS = [
  {
    initial: 'র',
    name: 'রহিম সরকার',
    meta: 'ঢাকা • ২ দিন আগে',
    body: 'অসাধারণ প্রোডাক্ট! সত্যিই কাজ করে। ৩৫ মিনিট পর্যন্ত পার্থক্য টের পাই। রেকমেন্ড করছি।',
    color: 'rev-blue',
  },
  {
    initial: 'ম',
    name: 'মো. করিম',
    meta: 'চট্টগ্রাম • ৫ দিন আগে',
    body: '২ বছর ধরে ব্যবহার করছি। কোনো সাইড ইফেক্ট নেই, অরিজিনাল প্রোডাক্ট। ডেলিভারিও দ্রুত।',
    color: 'rev-green',
  },
  {
    initial: 'জ',
    name: 'জুলফিকার আলী',
    meta: 'সিলেট • ১ সপ্তাহ আগে',
    body: 'প্রথমে সন্দেহ ছিল, কিন্তু ব্যবহার করে সত্যিই অবাক হলাম। দারুণ কাজ করে।',
    color: 'rev-orange',
  },
  {
    initial: 'ম',
    name: 'মাহমুদুল হাসান',
    meta: 'রাজশাহী • ১০ দিন আগে',
    body: 'গোপনীয় প্যাকেজিংয়ে ডেলিভারি পেয়েছি, খুব ভালো লাগলো। প্রোডাক্টও অরিজিনাল।',
    color: 'rev-purple',
  },
];

const FAQS = [
  {
    q: 'কিভাবে ব্যবহার করব?',
    a: 'প্রতিবার সহবাসের ২-৩ মিনিট আগে লিঙ্গ ধুয়ে শুকনো কাপড় বা টিস্যু দিয়ে মুছে নেবেন। তারপর লিঙ্গের আগা থেকে অর্ধেক পর্যন্ত ২-৩ বার মুছবেন টিস্যুটি দিয়ে এবং চারপাশে একটু মালিশ করবেন। ৩০ সেকেন্ডের মধ্যে শুকিয়ে যাবে। ২ মিনিট অপেক্ষা করে সহবাসে যাবেন।',
  },
  {
    q: 'এটা কি অরিজিনাল প্রোডাক্ট?',
    a: 'হ্যাঁ। ম্যাজিক টিস্যু অরিজিনাল জার্মানির প্রোডাক্ট। প্যাকেটের নিচে বারকোড স্ক্যানার থাকবে — চেক করে নিতে পারবেন। মেয়াদ ৩ বছর থাকবে।',
  },
  {
    q: 'কোনো সাইড ইফেক্ট আছে কি?',
    a: 'না। এটি জার্মান ল্যাব থেকে পরীক্ষিত এবং সম্পূর্ণ পার্শ্বপ্রতিক্রিয়ামুক্ত। এটি শুধু বাইরে ব্যবহার করার জন্য, শরীরের ভিতরে যায় না। তাই কোনো ধরনের সমস্যার ঝুঁকি নেই।',
  },
  {
    q: 'ডেলিভারি কতদিনে পাব?',
    a: 'ঢাকার ভিতরে ২৪-৭২ ঘণ্টার মধ্যে। ঢাকার বাইরে ২-৪ কার্যদিবস। প্যাকেজিং সম্পূর্ণ গোপনীয় এবং নিরাপদ। ডেলিভারি চার্জ: ঢাকার ভিতরে ৳৬০, ঢাকার বাইরে ৳১২০।',
  },
  {
    q: 'পেমেন্ট কিভাবে করব?',
    a: 'ক্যাশ অন ডেলিভারি — পণ্যটি হাতে নিয়ে চেক করে তারপর পেমেন্ট করতে পারবেন। আগে কোনো টাকা দিতে হবে না।',
  },
  {
    q: 'অর্ডার কিভাবে করব?',
    a: 'এই পেজ থেকে সরাসরি অর্ডার করতে পারবেন, অথবা আমাদের হটলাইন নম্বরে কল করুন। WhatsApp বা Facebook-এও অর্ডার নেওয়া হয়।',
  },
];

type CountdownState = { hours: number; minutes: number; seconds: number };
type PackageKey = keyof typeof PACKAGES;
type DeliveryKey = keyof typeof DELIVERY_OPTIONS;
type SubmitState = 'idle' | 'submitting' | 'success' | 'error';

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}

function useCountdown(initial: CountdownState): CountdownState {
  const [time, setTime] = useState<CountdownState>(initial);

  useEffect(() => {
    const id = window.setInterval(() => {
      setTime((prev) => {
        let { hours, minutes, seconds } = prev;
        if (seconds > 0) seconds -= 1;
        else if (minutes > 0) {
          seconds = 59;
          minutes -= 1;
        } else if (hours > 0) {
          seconds = 59;
          minutes = 59;
          hours -= 1;
        } else {
          hours = 5;
          minutes = 47;
          seconds = 31;
        }
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => window.clearInterval(id);
  }, []);

  return time;
}

function Stars() {
  return (
    <span className="stars" aria-label="৪.৮ তারকা রেটিং">
      ★★★★★
    </span>
  );
}

function PromoBar() {
  const time = useCountdown({ hours: 5, minutes: 47, seconds: 31 });

  return (
    <div className="promo-bar">
      <div className="container promo-inner">
        <span>অফার সীমিত সময়ের জন্য! আজই অর্ডার করুন — ক্যাশ অন ডেলিভারি</span>
        <span className="promo-timer" role="timer" aria-live="polite">
          {pad(time.hours)}:{pad(time.minutes)}:{pad(time.seconds)}
        </span>
      </div>
    </div>
  );
}

function Header() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <a className="brand" href="#top" aria-label="Magic Tissue">
          <img src={PRODUCT_IMAGES[0]} alt="" className="brand-thumb" />
          <span className="brand-text">
            <span className="brand-name">Magic Tissue</span>
            <span className="brand-sub">ম্যাজিক টিস্যু</span>
          </span>
        </a>
        <nav className="header-cta" aria-label="যোগাযোগ">
          <a className="btn btn-ghost" href="#order-form">অর্ডার</a>
          <a className="btn btn-blue" href={PHONE}>📞 কল করুন</a>
          <a className="btn btn-green" href={WHATSAPP} target="_blank" rel="noopener noreferrer">💬 WhatsApp</a>
          <a className="btn btn-fb" href={FACEBOOK} target="_blank" rel="noopener noreferrer">📘 Facebook</a>
        </nav>
      </div>
    </header>
  );
}

function Hero() {
  const [active, setActive] = useState(0);

  return (
    <section className="hero-shell">
      <div className="container hero-grid">
        <div className="hero-content">
          <div className="hero-badges">
            <span className="badge badge-gold">অরিজিনাল জার্মান প্রোডাক্ট</span>
            <span className="badge badge-green">১০০% কার্যকর</span>
          </div>
          <h1 className="hero-title">ম্যাজিক টিস্যু</h1>
          <p className="hero-subtitle">পুরুষদের আত্মবিশ্বাসের সেরা সঙ্গী</p>
          <div className="hero-rating">
            <Stars />
            <span className="rating-value">4.8</span>
            <span className="rating-count">(2,847 রিভিউ)</span>
          </div>
          <div className="hero-offer-card">
            <div>
              <span className="offer-kicker">আজকের অফার</span>
              <strong>Starter Pack মাত্র ৳490</strong>
            </div>
            <a className="btn btn-order btn-lg" href="#order-form">এখনই অর্ডার করুন</a>
          </div>
          <ul className="benefits">
            {BENEFITS.map((benefit) => (
              <li key={benefit} className="benefit-row">
                <span className="benefit-check" aria-hidden="true">✓</span>
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="hero-product-card">
          <div className="hero-image-frame">
            <img src={PRODUCT_IMAGES[active]} alt="Magic Tissue Product" className="hero-image" />
            <span className="image-pill">গোপন প্যাকেজিং</span>
          </div>
          <div className="hero-thumbs" role="tablist" aria-label="পণ্যের ছবি">
            {PRODUCT_IMAGES.map((src, i) => (
              <button
                key={src}
                type="button"
                role="tab"
                aria-selected={active === i}
                className={`hero-thumb ${active === i ? 'is-active' : ''}`}
                onClick={() => setActive(i)}
              >
                <img src={src} alt={`Magic Tissue ছবি ${i + 1}`} />
              </button>
            ))}
          </div>
          <div className="hero-mini-proof">
            <span>💵 পেয়ে পেমেন্ট</span>
            <span>🔒 ১০০% প্রাইভেট</span>
            <span>🚚 দ্রুত ডেলিভারি</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustStrip() {
  return (
    <section className="container trust-section" aria-label="বিশ্বাসযোগ্যতা">
      <div className="trust-grid">
        {TRUST_ITEMS.map((item) => (
          <div className="trust-card" key={item.label}>
            <span className="trust-icon" aria-hidden="true">{item.icon}</span>
            <span className="trust-label">{item.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Pricing({ selected, setSelected }: { selected: PackageKey; setSelected: (value: PackageKey) => void }) {
  return (
    <section className="container pricing-section" id="order">
      <div className="section-heading">
        <span className="section-kicker">প্যাকেজ</span>
        <h2 className="section-title-center">আপনার জন্য সেরা অফার বেছে নিন</h2>
        <p className="section-sub-center">অর্ডার কনফার্ম করার আগে সব চার্জ পরিষ্কারভাবে দেখানো হয়েছে</p>
      </div>

      <div className="pricing-grid">
        {(Object.keys(PACKAGES) as PackageKey[]).map((key) => {
          const item = PACKAGES[key];
          const featured = key === 'premier';
          return (
            <button
              key={key}
              type="button"
              className={`pricing-card ${featured ? 'pricing-card-featured' : ''} ${selected === key ? 'is-selected' : ''}`}
              onClick={() => setSelected(key)}
              aria-pressed={selected === key}
            >
              {featured && <span className="pricing-ribbon">সর্বোচ্চ সাশ্রয়</span>}
              <div className="pricing-head">
                <span className="pricing-name">{item.short}</span>
                <span className="pricing-qty">{item.qty}</span>
              </div>
              <div className="pricing-price">৳{item.price}</div>
              <p className="pricing-note">{item.note}</p>
              <span className="pricing-select">{selected === key ? 'নির্বাচিত' : 'নির্বাচন করুন'}</span>
            </button>
          );
        })}
      </div>

      <div className="delivery-card">
        <div className="delivery-row"><span>🚚 ঢাকার ভিতরে ডেলিভারি:</span><strong>৳60</strong></div>
        <div className="delivery-row"><span>🚚 ঢাকার বাইরে ডেলিভারি:</span><strong>৳120</strong></div>
        <div className="delivery-cod"><span aria-hidden="true">💵</span><span>ক্যাশ অন ডেলিভারি — পণ্যটি হাতে নিয়ে চেক করে পেমেন্ট করুন।</span></div>
      </div>

      <div className="order-cta-stack">
        <a href="#order-form" className="btn btn-order">এখনই অর্ডার করুন</a>
        <div className="order-cta-row">
          <a className="btn btn-blue" href={PHONE}>📞 কল করুন</a>
          <a className="btn btn-green" href={WHATSAPP} target="_blank" rel="noopener noreferrer">💬 WhatsApp</a>
          <a className="btn btn-fb" href={FACEBOOK} target="_blank" rel="noopener noreferrer">📘 Facebook</a>
        </div>
      </div>
    </section>
  );
}

function OrderForm({
  packageKey,
  setPackageKey,
  deliveryKey,
  setDeliveryKey,
  quantity,
  setQuantity,
}: {
  packageKey: PackageKey;
  setPackageKey: (value: PackageKey) => void;
  deliveryKey: DeliveryKey;
  setDeliveryKey: (value: DeliveryKey) => void;
  quantity: number;
  setQuantity: (value: number) => void;
}) {
  const [submitState, setSubmitState] = useState<SubmitState>('idle');

  const selectedPackage = PACKAGES[packageKey];
  const selectedDelivery = DELIVERY_OPTIONS[deliveryKey];
  const total = useMemo(() => selectedPackage.price * quantity + selectedDelivery.price, [quantity, selectedDelivery.price, selectedPackage.price]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitState('submitting');

    const form = event.currentTarget;
    const data = new FormData(form);

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: data,
        headers: { Accept: 'application/json' },
      });
      const result = await response.json();

      if (response.ok && result.success) {
        setSubmitState('success');
        form.reset();
        setPackageKey('starter');
        setDeliveryKey('inside');
        setQuantity(1);
      } else {
        setSubmitState('error');
      }
    } catch {
      setSubmitState('error');
    }
  }

  return (
    <section className="container order-form-section" id="order-form">
      <div className="order-form-card">
        <div className="order-form-copy">
          <span className="order-form-badge">ক্যাশ অন ডেলিভারি</span>
          <h2 className="section-title">অর্ডার ফর্ম</h2>
          <p className="order-form-lead">নিচের তথ্য দিন, আমরা দ্রুত কনফার্ম করব। আপনার প্যাকেজিং সম্পূর্ণ গোপনীয় থাকবে।</p>
          <div className="order-summary" aria-live="polite">
            <div><span>প্যাকেজ</span><strong>{selectedPackage.label}</strong></div>
            <div><span>পরিমাণ</span><strong>{quantity}</strong></div>
            <div><span>ডেলিভারি</span><strong>৳{selectedDelivery.price}</strong></div>
            <div><span>সময়</span><strong>{selectedDelivery.time}</strong></div>
            <div className="order-summary-total"><span>মোট</span><strong>৳{total}</strong></div>
          </div>
        </div>

        <form className="order-form" action="https://api.web3forms.com/submit" method="POST" onSubmit={handleSubmit}>
          <input type="hidden" name="access_key" value={WEB3FORMS_ACCESS_KEY} />
          <input type="hidden" name="subject" value="New Magic Tissue Order" />
          <input type="hidden" name="from_name" value="Magic Tissue Website" />
          <input type="hidden" name="package" value={selectedPackage.label} />
          <input type="hidden" name="package_price" value={`৳${selectedPackage.price}`} />
          <input type="hidden" name="quantity" value={quantity} />
          <input type="hidden" name="delivery_area" value={selectedDelivery.label} />
          <input type="hidden" name="delivery_charge" value={`৳${selectedDelivery.price}`} />
          <input type="hidden" name="total_amount" value={`৳${total}`} />
          <input type="checkbox" name="botcheck" className="hidden-field" tabIndex={-1} autoComplete="off" />

          <label>নাম<input name="name" type="text" placeholder="আপনার নাম" required /></label>
          <label>ফোন নম্বর<input name="phone" type="tel" inputMode="tel" placeholder="01XXXXXXXXX" required /></label>
          <label>সম্পূর্ণ ঠিকানা<textarea name="address" rows={3} placeholder="বাসা/রোড/এলাকা/জেলা" required /></label>

          <div className="form-grid-two">
            <label>
              প্যাকেজ
              <select name="selected_package" value={packageKey} onChange={(event) => setPackageKey(event.target.value as PackageKey)}>
                <option value="starter">Starter Pack — ১০ পিস — ৳490</option>
                <option value="premier">Premier Pack — ২০ পিস — ৳900</option>
              </select>
            </label>
            <label>
              পরিমাণ
              <input
                name="selected_quantity"
                type="number"
                min="1"
                max="20"
                value={quantity}
                onChange={(event) => setQuantity(Math.max(1, Number(event.target.value) || 1))}
                required
              />
            </label>
          </div>

          <label>
            ডেলিভারি এলাকা
            <select name="selected_delivery_area" value={deliveryKey} onChange={(event) => setDeliveryKey(event.target.value as DeliveryKey)}>
              <option value="inside">ঢাকার ভিতরে — ৳60</option>
              <option value="outside">ঢাকার বাইরে — ৳120</option>
            </select>
          </label>
          <label>নোট / অতিরিক্ত তথ্য<textarea name="note" rows={2} placeholder="ঐচ্ছিক" /></label>

          <div className="form-total-row"><span>মোট পেমেন্ট</span><strong>৳{total}</strong></div>
          {submitState === 'success' && <p className="form-message form-message-success">অর্ডার পাঠানো হয়েছে। আমরা দ্রুত যোগাযোগ করব।</p>}
          {submitState === 'error' && <p className="form-message form-message-error">অর্ডার পাঠানো যায়নি। দয়া করে কল বা WhatsApp করুন।</p>}
          <button className="btn btn-order form-submit" type="submit" disabled={submitState === 'submitting'}>
            {submitState === 'submitting' ? 'পাঠানো হচ্ছে...' : 'অর্ডার সাবমিট করুন'}
          </button>
        </form>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section className="container services-section">
      <div className="services-grid">
        {SERVICES.map((item) => (
          <div className="service-card" key={item.title}>
            <span className="service-icon" aria-hidden="true">{item.icon}</span>
            <div><div className="service-title">{item.title}</div><div className="service-sub">{item.sub}</div></div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Steps() {
  return (
    <section className="container steps-section">
      <div className="section-heading">
        <span className="section-kicker">ব্যবহারবিধি</span>
        <h2 className="section-title-center">কিভাবে ব্যবহার করবেন?</h2>
        <p className="section-sub-center">মাত্র ৩টি সহজ ধাপে ব্যবহার করুন</p>
      </div>
      <div className="steps-grid">
        {STEPS.map((step) => (
          <article className="step-card" key={step.label}>
            <span className="step-icon" aria-hidden="true">{step.icon}</span>
            <span className="step-label">{step.label}</span>
            <h3 className="step-title">{step.title}</h3>
            <p className="step-body">{step.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function WhyChoose() {
  return (
    <section className="container why-section">
      <div className="section-heading">
        <span className="section-kicker">বিশ্বাস</span>
        <h2 className="section-title-center">কেন ম্যাজিক টিস্যু বেছে নেবেন?</h2>
        <p className="section-sub-center">হাজার হাজার সন্তুষ্ট গ্রাহকের বিশ্বস্ত পছন্দ</p>
      </div>
      <div className="why-grid">
        {WHY_ITEMS.map((item) => (
          <article className="why-card" key={item.title}>
            <span className="why-icon" aria-hidden="true">{item.icon}</span>
            <h3 className="why-title">{item.title}</h3>
            <p className="why-body">{item.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function Reviews() {
  return (
    <section className="container reviews-section">
      <div className="section-heading">
        <span className="section-kicker">রিভিউ</span>
        <h2 className="section-title-center">গ্রাহকদের মতামত</h2>
        <p className="section-sub-center"><Stars /> <strong>4.8/5</strong> <span className="muted">(2,847)</span></p>
      </div>
      <div className="reviews-grid">
        {REVIEWS.map((review) => (
          <article className="review-card" key={review.name}>
            <header className="review-head">
              <span className={`review-avatar ${review.color}`} aria-hidden="true">{review.initial}</span>
              <div><div className="review-name">{review.name}</div><div className="review-meta">{review.meta}</div></div>
            </header>
            <div className="review-stars" aria-hidden="true"><Stars /></div>
            <p className="review-body">{review.body}</p>
            <span className="review-verified">✓ যাচাইকৃত ক্রয়</span>
          </article>
        ))}
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="container faq-section">
      <div className="section-heading">
        <span className="section-kicker">প্রশ্নোত্তর</span>
        <h2 className="section-title-center">সাধারণ প্রশ্নোত্তর</h2>
        <p className="section-sub-center">আপনার সকল প্রশ্নের উত্তর এখানে</p>
      </div>
      <div className="faq-list">
        {FAQS.map((faq, i) => {
          const isOpen = open === i;
          return (
            <div className={`faq-item ${isOpen ? 'is-open' : ''}`} key={faq.q}>
              <button type="button" className="faq-q" aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : i)}>
                <span>{faq.q}</span>
                <span className="faq-toggle" aria-hidden="true">{isOpen ? '−' : '+'}</span>
              </button>
              {isOpen && <div className="faq-a">{faq.a}</div>}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section className="final-cta">
      <div className="container final-inner">
        <span className="final-badge">সীমিত সময়ের অফার</span>
        <h2 className="final-title">আজই আত্মবিশ্বাস ফিরে পান!</h2>
        <p className="final-sub">হাজার হাজার পুরুষ ইতিমধ্যে উপকৃত হয়েছেন — আপনার পালা!</p>
        <div className="final-line">এখনই অর্ডার করুন — Starter Pack মাত্র ৳490</div>
        <p className="final-meta">ক্যাশ অন ডেলিভারি | গোপন প্যাকেজিং | ১০০% অরিজিনাল</p>
        <div className="final-btns">
          <a className="btn btn-blue btn-lg" href={PHONE}>📞 কল</a>
          <a className="btn btn-green btn-lg" href={WHATSAPP} target="_blank" rel="noopener noreferrer">💬 WhatsApp</a>
          <a className="btn btn-order btn-lg" href="#order-form">অর্ডার — ৳490</a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-inner">
        <div className="footer-brand"><div className="footer-name">Magic Tissue</div><p className="footer-tag">সেরা মানের ব্যক্তিগত পরিচর্যা পণ্য</p></div>
        <div className="footer-links">
          <a href={PHONE}>📞 +880 1336-580900</a>
          <a href={WHATSAPP} target="_blank" rel="noopener noreferrer">💬 WhatsApp</a>
          <a href={FACEBOOK} target="_blank" rel="noopener noreferrer">📘 Facebook</a>
        </div>
        <div className="footer-meta">ডেলিভারি চার্জ: ঢাকার ভিতরে ৳৬০ | ঢাকার বাইরে ৳১২০</div>
        <div className="footer-policy"><a href="#top">গোপনীয়তা নীতি</a><span aria-hidden="true">|</span><a href="#top">শর্তাবলী</a></div>
        <div className="footer-copy">© 2026 Magic Tissue. সকল অধিকার সংরক্ষিত।</div>
      </div>
    </footer>
  );
}

function FloatingConversionBar({ total }: { total: number }) {
  return (
    <div className="floating-bar" aria-label="দ্রুত অর্ডার">
      <a href={PHONE} className="floating-link floating-call">কল</a>
      <a href="#order-form" className="floating-link floating-order">অর্ডার — ৳{total}</a>
      <a href={WHATSAPP} className="floating-link floating-whatsapp" target="_blank" rel="noopener noreferrer">WhatsApp</a>
    </div>
  );
}

export default function App() {
  const [packageKey, setPackageKey] = useState<PackageKey>('starter');
  const [deliveryKey, setDeliveryKey] = useState<DeliveryKey>('inside');
  const [quantity, setQuantity] = useState(1);
  const selectedPackage = PACKAGES[packageKey];
  const selectedDelivery = DELIVERY_OPTIONS[deliveryKey];
  const total = selectedPackage.price * quantity + selectedDelivery.price;

  return (
    <div id="top" className="app">
      <PromoBar />
      <Header />
      <main>
        <Hero />
        <TrustStrip />
        <Pricing selected={packageKey} setSelected={setPackageKey} />
        <OrderForm
          packageKey={packageKey}
          setPackageKey={setPackageKey}
          deliveryKey={deliveryKey}
          setDeliveryKey={setDeliveryKey}
          quantity={quantity}
          setQuantity={setQuantity}
        />
        <Services />
        <Steps />
        <WhyChoose />
        <Reviews />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
      <FloatingConversionBar total={total} />
    </div>
  );
}
